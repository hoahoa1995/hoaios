-- hbdevice rotate.lua
-- Runs in iam dylib Lua runtime (SpringBoard = HOST sandbox).
-- Reads staged XML files + copies to REAL path via shell exec.
-- Called from hbdevice helper via POST http://127.0.0.1:8888/api/lua/run/file.

-- CLI stages XML files under hbdevice data dir (mobile-owned, both jbroot
-- and HOST sandbox see same path consistently — no shadow redirect because
-- /var/mobile isn't a jbroot alias like /var/tmp).
local STAGE_DIR = "/var/mobile/Library/hbdevice"
local DST_DIR = "/var/mobile/Library/Preferences"
local JOBS = {
  { "hbd-rotate-snap.xml",  "com.nvfrk.iosautomate.device.snapshot.plist" },
  { "hbd-rotate-fast.xml",  "com.nvfrk.iosautomate.device.fast.reset.last.plist" },
  { "hbd-rotate-low.xml",   "com.nvfrk.iosautomate.device.low.last.plist" },
}

for _, job in ipairs(JOBS) do
  local src = STAGE_DIR .. "/" .. job[1]
  local dst = DST_DIR .. "/" .. job[2]
  local shadow = "/rootfs/private" .. dst
  -- Remove jbroot shadow overlay so follow-up write resolves to REAL.
  execute("rm -f '" .. shadow .. "'")
  -- Copy staged payload to REAL destination.
  execute("cp '" .. src .. "' '" .. dst .. "'")
  execute("chown mobile:mobile '" .. dst .. "'")
  execute("chmod 644 '" .. dst .. "'")
  execute("rm -f '" .. src .. "'")
  log("rotate: wrote " .. dst)
end

-- Kick nvfrk daemons + MG so reload picks up new profile.
-- CRITICAL: do NOT `killall -9 cfprefsd` — SB depends on cfprefsd and
-- iam's Lua safety-mechanism detects SB instability → disables further
-- Lua execution ("sập máy" warnings in log). Use SIGTERM via launchctl
-- kickstart instead which gracefully restarts the daemon.
-- Also skip Preferences/WSDaemon/WSdaemon_SFM kills — iam watches these.
execute("killall -9 Facebook 2>/dev/null")
execute("launchctl kickstart -k system/com.apple.mobilegestalt.xpc 2>/dev/null")
execute("launchctl kickstart -k system/com.nvfrk.sfm.toolsd 2>/dev/null")
execute("launchctl kickstart -k system/com.nvfrk.iosautomate.touch.daemon 2>/dev/null")

log("rotate: done")
